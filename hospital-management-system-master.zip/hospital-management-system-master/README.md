## Hospital Management System

OOP Project.

# Tools used
  - JavaFX
  - MySQL
  - SceneBuilder

# Things I learned: 
  
  - How to make reuseable code
  - How to use MySQL database 
  - How to use SceneBuilder
  - How to make the UI more attractive
  - How to implement Login/Registration process.
  - How to not cry after a long hard day at work
